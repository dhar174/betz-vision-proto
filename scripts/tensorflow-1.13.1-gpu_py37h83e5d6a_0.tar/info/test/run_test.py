#  tests for tensorflow-1.13.1-gpu_py37h83e5d6a_0 (this is a generated file);
print('===== testing package: tensorflow-1.13.1-gpu_py37h83e5d6a_0 =====');
print('running run_test.py');
#  --- run_test.py (begin) ---
import tensorflow as tf
hello = tf.constant('Hello, TensorFlow!')
sess = tf.Session()
out = sess.run(hello)
a = tf.constant(10)
b = tf.constant(32)
sess.run(a+b)
#  --- run_test.py (end) ---

print('===== tensorflow-1.13.1-gpu_py37h83e5d6a_0 OK =====');
print("import: 'tensorflow'")
import tensorflow

print("import: 'tensorboard'")
import tensorboard

